sudo yarn install --production &&
sudo pm2 startOrRestart ecosystem.config.js --env production
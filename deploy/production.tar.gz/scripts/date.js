const moment = require("moment");

console.log(moment().format("HH:mm:ss"));
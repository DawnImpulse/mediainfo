module.exports = {
    apps : [{
        name: "visualoud-gateway",
        cwd: ".",
        script: "yarn start"
    }]
}